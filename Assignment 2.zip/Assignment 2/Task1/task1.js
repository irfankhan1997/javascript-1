var marks = parseInt(prompt("Enter Your Marks :"));

if(marks >90){
    console.log("A+");
}else if (marks >80 && marks <=90){
    console.log("A");
}else if (marks >70 && marks <=80){
    console.log("B+");
}else if (marks >60 && marks <=70){
    console.log("B");
}else if (marks >50 && marks <=60){
    console.log("C");
}else if (marks >40 && marks <=50){
    console.log("D");
}else if (marks >34 && marks <=40){
    console.log("E");
}else if ( marks <=33){
    console.log("F");
}