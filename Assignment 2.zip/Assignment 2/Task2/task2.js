var num = parseInt(prompt("Enter Your Number :"));

switch (num) {
    case 1:
        alert("ONE");
        break;

    case 2:
        alert("TWO");
        break;

    case 3:
        alert("THREE");
        break;

    case 4:
        alert("FOUR");
        break;

    case 5:
        alert("FIVE");
        break;

    case 6:
        alert("SIX");
        break;

    case 7:
        alert("SEVEN");
        break;

    case 8:
        alert("EIGHT");
        break;

    case 9:
        alert("NINE");
        break;

    default:
        alert("PLEASE TRY AGAIN");
        break;
}
